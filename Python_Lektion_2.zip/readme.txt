
******************************************************************************************************
**										    	       **	
** 	Copyright : IU Internationale Hochschule GmbH, Juri-Gagarin-Ring 152, D-99084 Erfurt	       **		 
**										    	       **	
******************************************************************************************************

****************************************************************************************************************
** 													**
**	example_2_1.py : Vertauschen zweiter Spalten in einem CSV File		    			**
**	example_2_2.py : Auslesen bestimmter Variablen aus einem XML Metadatenfile				**	
**	example_2_3.py : Berechnung der Genauigkeit der Untermenge an gegeben Messwerten			**
**	example_2_4.py : Berechnung der Konvergenz bei der Berechnung der Kreiszahl pi mit Zufallszahlen	**
**	example_2_5.py : Berechnung eines quantenmechanischen Wellenfeldes mit Darstellung 			**
**			als 2D Histogramm 								**
**	example_2_6.py : Berechnung und Darstellung von zwei-dimensionalen Graphen mit Scatter Plots		**																				
**	example_2_7.py : Berechnung von Graphen mit linearer, vektor-basierter und polynomieller Regression	**
**	example_2_8.py : Vergleich von Anomalien in Datensätzen mit unterscheidlichen Verfahren		**
**	example_2_9.py : Analyse der Genauigkeit von Gesichterkennung per PCA (randomized SVC)   		**	
**	example_2_10.py : Vergleich von linearen und nicht-linearen Feature Klassifizierungen 		**
**													**  	      
****************************************************************************************************************


The same for Jupyter files, which are labeled with notebook_example_2_x.ipynb.

Password for Lecture ZIP File DLBDSIDS_D is 'IU-Notebook-DLBDSIDS_D'.