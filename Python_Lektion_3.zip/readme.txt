
******************************************************************************************************
**										    	       **	
** 	Copyright : IU Internationale Hochschule GmbH, Juri-Gagarin-Ring 152, D-99084 Erfurt	       **		 
**										    	       **	
******************************************************************************************************

****************************************************************************************************************
** 												        **
**	example_3_1.py : Veranschaulichung von Use-Cases mit der Routine pandas loc and iloc		        **
**	example_3_2.py : Spezifizität und Sensitivität für ein Zweiklassenproblem 			        **	
**	example_3_3.py : Analyse und Illustration von Social Network Graphen			        **
**	example_3_4.py : Berechnung der Gewinne als Funktion der Investition in eine 6 aus 49 Lotterie       **
**												        **
****************************************************************************************************************

The same for Jupyter files, which are labeled with notebook_example_3_x.ipynb.

Password for Lecture ZIP File DLBDSIDS_D is 'IU-Notebook-DLBDSIDS_D'.

