
******************************************************************************************************
**										    	       **	
** 	Copyright : IU Internationale Hochschule GmbH, Juri-Gagarin-Ring 152, D-99084 Erfurt	       **		 
**										    	       **	
******************************************************************************************************

**********************************************************************************************************************************
** 												     			 **
**	example_5_1.py : PYTHON ROUTINE zur Analyse und Klassifizerung von Strukturen eines Datensatzes aus zwei Komponenten	 **
**	example_5_2.py : PYTHON ROUTINE zum Vergleich von LDA und PCA-2D Projektion eines Iris Datensatzes			 **
**	example_5_3.py : PYTHON ROUTINE zur Rekonstruktion von Strukturen eines Datensatzes aus drei Signalen			 **
**	example_5_4.py : PYTHON ROUTINE zur kPCA Analyse und Klassifizerung von Strukturen eines Datensatzes aus 2 Komponenten **
**	example_5_5.py : PYTHON ROUTINE zur Modellierung eines Datensates mit der Dictionary Learning Methode			 **
**	example_5_6.py : PYTHON ROUTINE zur Analyse eines Datensates mit der Faktor Analyse					 **
**	example_5_7.py : PYTHON ROUTINE zur Modellierung eines Datensates mit der Dictionary Learning Methode			 **
**	example_5_8.py : PYTHON ROUTINE zur Analyse von Komponenten eines Datensatzes mittels LDA-Analyse 			 **
**															 **
**********************************************************************************************************************************

The same for Jupyter files, which are labeled with notebook_example_5_x.ipynb.

Password for Lecture ZIP-File DLBDSIDS_D is 'IU-Notebook-DLBDSIDS_D'.