
******************************************************************************************************
										    	       	
 	Copyright : IU Internationale Hochschule GmbH, Juri-Gagarin-Ring 152, D-99084 Erfurt	       		 
										    	       	
******************************************************************************************************


************************************************************************************
									    	
	example_1_1.py : Berechnen einer Cosinusfunktion			    	
	example_1_2.py : Pandas Tabelle					    	
	example_1_3.py : Illustration einer Standard IF-Abfrage		    
	example_1_4.py : Illustration des Aufbaus künstlicher Intelligenz	    
	example_1_5.py : MapReduce Instanz				    
	example_1_6.py : Berechnung einfacher Eigenwertgleichungen		    
	example_1_7.py : Berechnung von Ableitungen einer Funktion		   
	example_1_8.py : Erzeugung eines Wellenpakets			    	
	example_1_9.py : Berechnung von Extremwerten			    
	example_1_10.py : Einfacher Lernalgorithmus 			    			      
	example_1_11.py : Numerischer Beweis Gaußscher Grenzwertsatz	    
	example_1_12.py : Berechnung der Kreiszahl pi mit Zufallszahlen	           
	example_1_13.py : Normierung von Matrizen				    
	example_1_14.py : Berechnung der Kreiszahl pi mit Pyspark	            
	example_1_15.py : Berechnung der Kreiszahl pi mit Parallel Algorithmus 
									    
************************************************************************************


The same for Jupyter files, which are labeled with notebook_example_1_x.ipynb.

Password for Lecture ZIP File DLBDSIDS_D is 'IU-Notebook-DLBDSIDS_D'.