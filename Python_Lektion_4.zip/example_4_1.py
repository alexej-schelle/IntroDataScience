
################################################################################################################################################
#                                                                                                                                              #
#    Autor: Dr. A. Schelle (alexej.schelle.ext@iu.org). Copyright : IU Internationale Hochschule GmbH, Juri-Gagarin-Ring 152, D-99084 Erfurt   #
#                                                                                                                                              #
################################################################################################################################################

################################################################################
#                                                                              # 
#   PYTHON ROUTINE zur Berechnung von Gewinnen aus der Monty Hall Stategie     #
#                                                                              # 
################################################################################ 

import os
import sys
import math
import numpy
import numpy as np
import matplotlib.pyplot as plt
import csv
import random
import pandas

# Definiere die Parameter 

win_standard = [] # Anzahl der Gewinne in einer Stand Lotterie 
win_clever = [] # Anzahl der Gewinne in einer Monty Hall Strategie

main_win = 1000000.0 # Wert des Gesamtgewinns
k = j = 0

sample_size = 1000000 # Anzahl der Iterationen

for m in range(sample_size):

    j = random.randint(0,2) # Erstelle eine Zufallsdarstellung pro Realisierung 
    ran_seq = [100.0, 100.0, 100.0] # Initialer Vektor
    
    for k in range(0,3): # Generiere den entsprchenden Vektor
        
        if (k == j): ran_seq[k] = main_win

    if (ran_seq[0] == main_win) : win_standard.append(ran_seq[0]) # Zähle alle Gewinne in der Standard Strategie
    
    if (ran_seq[2] != main_win) : # Zähle alle Gewinne in der Count all wins in the Monty strategy

        if (ran_seq[1] == main_win) : win_clever.append(ran_seq[1])
       
    else:

        if (ran_seq[0] == main_win) : win_clever.append(ran_seq[0])

print('How much is the probability increased for Monty to win the toss using his strategy ?', math.fabs((len(win_clever) - len(win_standard))/float(sample_size)*100.0), 'per cent')