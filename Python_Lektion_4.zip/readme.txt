
******************************************************************************************************
**										    	       **	
** 	Copyright : IU Internationale Hochschule GmbH, Juri-Gagarin-Ring 152, D-99084 Erfurt	       **		 
**										    	       **	
******************************************************************************************************

************************************************************************************************************
** 												     **
**	example_4_1.py : PYTHON ROUTINE zur Berechnung von Gewinnen aus der Monty Hall Strategie	     **
**	example_4_2.py : PYTHON ROUTINE zur Berechnung von Gauss-, Binomial- und Poissonverteilungen      **			        **	example_4_3.py : PYTHON ROUTINE zum Vergleich von Anomalien 				     **
**	example_4_4.py : PYTHON ROUTINE zur Berechnung der Kendall, Pearson und Spearman Korrelationen    **
**												     **
************************************************************************************************************

The same for Jupyter files, which are labeled with notebook_example_4_x.ipynb.

Password for Lecture ZIP-File DLBDSIDS_D is 'IU-Notebook-DLBDSIDS_D'.
